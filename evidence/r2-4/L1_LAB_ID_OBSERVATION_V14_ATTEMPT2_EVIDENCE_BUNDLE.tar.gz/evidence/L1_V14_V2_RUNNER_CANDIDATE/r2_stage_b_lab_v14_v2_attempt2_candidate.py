#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

API_VERSION = "2026-03-10"

OWNER = "SrHector199"
PROD_REPO = "SrHector199/desarrollo-gobernado-r2"
LAB_REPO = "SrHector199/r2-stage-b-platform-semantics-lab-v13-e8a44c52"
LAB_REPO_NAME = "r2-stage-b-platform-semantics-lab-v13-e8a44c52"

EXPECTED_PROD_MAIN = "5a5b4b1bd95f50824180e2146f9d76fbe861db7c"
EXPECTED_STATE_BLOB = "d8e5c7796322c6ac60761dba3485f69d15debe6b"
EXPECTED_PR6_HEAD = "4d0b627e28fd863aff7169529f99cd5d5ae5805c"
EXPECTED_LAB_MAIN = "ec5eae95c6eec166713259d0a76dc13261e22c68"

DESIGN_SHA = "e8a44c52bafb847faa6beedc778d1726ea1f76e5dbd3bf90923614e03b866491"
DESIGN_BYTES = 133876
REVIEW_SHA = "223bc7ff00a207b6b5161fcb18a629d139a468efbcceb2aa386d779541d307f6"
REVIEW_BYTES = 50914
V14_V2_SHA = "ed51fa1ed31e1d05a75587eecb70b214b6f62d0bb4d57eb2f641966ca4016d84"
V14_V2_BYTES = 9126
HARNESS_SPEC_SHA = "4a5b747427c77da2a3484a9398a19036c82664c12e867b6b120e92ebe2b5aa40"
HARNESS_SPEC_BYTES = 1885
FORENSICS_SHA = "b4ccd60e52a8884e991175c0648771807e19f8e78866d35061d4ad089ea98270"
FORENSICS_BYTES = 5926
V14_V2_REVIEW_SHA = "3a73b2595aacccdc17b4d975918a06e3467f5151bc2c019c1b2ebe820965ec91"
V14_V2_REVIEW_BYTES = 57968
WRONG_INSTALL_RESULT_SHA = "f2098e652fd0f933c1668d82942ae2ea083361a6fb5103f5baf1d170aa9a6397"
WRONG_INSTALL_RESULT_BYTES = 1437
HISTORICAL_STOP_SHA = "b7e0d8b298b29ca95510ae8d917ddba2e32e175400e68bfe590dfdfbba2d4469"
HISTORICAL_STOP_BYTES = 303
HISTORICAL_RUNNER_SHA = "949bf6558322fed79f68edd5e28a638630450804c0df97dd3c6542938f522308"
HISTORICAL_RUNNER_BYTES = 71441

EXPECTED_APP = {
    "label": "LAB_EXPECTED_APP",
    "id": 4641302,
    "installation_id": 154781449,
    "slug": "r2v13-expected-srh199-e8a44c52",
    "key": Path.home() / ".local/share/r2-stage-b-lab-v13/keys/lab_expected_app.pem",
    "fingerprint": "XGsSr0HNxfcZRPNSpLCDKoykc0wjPHZKL2W5qTtFdc8=",
}
WRONG_APP = {
    "label": "LAB_WRONG_APP",
    "id": 4641692,
    "installation_id": 154784106,
    "slug": "r2v13-wrong-srh199-e8a44c52",
    "key": Path.home() / ".local/share/r2-stage-b-lab-v13/keys/lab_wrong_app.pem",
    "fingerprint": "khsQtIKtTpUfovmA5pUT0KV+TIqe4o1osXAvoI5oI40=",
}
LAB_APPS = [EXPECTED_APP, WRONG_APP]

CONTEXT = "r2-lab-pin-v12"

HISTORICAL_ATTEMPT_1 = {
    "number": 1,
    "target": "lab/id-observation",
    "target_sha": "7a7fe9b9edb1f6fe88d73a434df9451b6f1efd92",
    "source": "lab-src/id-observation",
    "source_sha": "fa4a43c1d86dda3e3a2125f131ada8bb2cc42dbf",
    "manifest_id": "id-observation",
    "manifest_path": ".github/workflows/id-observation.yml",
}
ATTEMPT = {
    "number": 2,
    "target": "lab/id-observation-r2",
    "target_sha": "3f5d292c9f76c1347ca2b6d13e63e816cf214159",
    "source": "lab-src/id-observation-r2",
    "source_sha": "81bf9c0ec3e45bb05b0207cbb17068568f01970e",
    "manifest_id": "id-observation-r2",
    "manifest_path": ".github/workflows/id-observation-r2.yml",
    "manifest_sha256": "6c8654b8ea42c005a6f00aaad01f1861fbf5e81442b79594e3b2e3b005715681",
    "manifest_bytes": 315,
}
ATTEMPTS = [ATTEMPT]
EXPECTED_NEW_PR_NUMBER = 2

RUN_ROOT = Path.home() / "r2-stage-b-lab-v13-continuation-1"
INPUT = RUN_ROOT / "input"
EVIDENCE = RUN_ROOT / "evidence"
PREV_INSTALL_DIR = EVIDENCE / "L1_WRONG_APP_INSTALL"
CANDIDATE_BUILD_DIR = EVIDENCE / "L1_V14_V2_RUNNER_CANDIDATE"
CASE_DIR = EVIDENCE / "L1_LAB_ID_OBSERVATION_V14_ATTEMPT2"

DESIGN = INPUT / "r2_4_stage_b_platform_semantics_lab_design_v13.json"
REVIEW = INPUT / "r2_4_stage_b_platform_semantics_lab_independent_review_v5.json"
V14_V2 = EVIDENCE / "L1_V14_CORRECTED_ACQUISITION_V2/r2_4_stage_b_platform_semantics_lab_design_v14_delta_v2.json"
HARNESS_SPEC = EVIDENCE / "L1_V14_CORRECTED_ACQUISITION_V2/r2_4_stage_b_v14_harness_correction_spec_v1.json"
FORENSICS = EVIDENCE / "L1_V14_CAPTURE_PATH_FORENSICS/L1_V14_CAPTURE_PATH_FORENSICS_RESULT.json"
V14_V2_REVIEW = CANDIDATE_BUILD_DIR / "inputs/r2_4_stage_b_v14_v2_independent_review_result.json"
RUNNER_REVIEW_RESULT = (
    CANDIDATE_BUILD_DIR
    / "review/r2_4_stage_b_v14_v2_runner_candidate_independent_review_result.json"
)
HISTORICAL_STOP = EVIDENCE / "L1_LAB_ID_OBSERVATION/OBSERVATION_INVALID_STOP.json"
WRONG_INSTALL_RESULT = PREV_INSTALL_DIR / "L1_WRONG_APP_INSTALL_RESULT.json"

ACQUISITION_MAX_POLLS = 12
ACQUISITION_DELAY_SECONDS = 5
HISTORICAL_ATTEMPT_1_DISPOSITION = "HISTORICAL_V13_OBSERVATION_INVALID_CONSUMED"
ACQUISITION_EXHAUSTED_OUTCOME = "UNINFORMATIVE_UNCERTAIN"
EXECUTION_ENV = "R2_V14_V2_ATTEMPT2_HUMAN_GATE_D"
EXECUTION_ENV_VALUE = "YES"
V13_V14_V2_COMPOSITION = "V13_PLUS_EXPLICIT_V14_V2_OVERRIDES_ONLY"
MERGE_REF_PRECONDITION = "PR_GET_STARTED_BACKGROUND_JOB_AND_MERGEABLE_TRUE"
POST_MERGE_EVIDENCE_COMPATIBILITY = "OUT_OF_SCOPE_BLOCKING_BEFORE_ANY_MERGE_CASE"

HEX40 = re.compile(r"^[0-9a-f]{40}$")
HEX64 = re.compile(r"^[0-9a-f]{64}$")


class StopBeforeMutation(RuntimeError):
    pass


class StopAfterMutation(RuntimeError):
    pass


class ObservationInvalid(RuntimeError):
    pass


class AcquisitionUninformativeUncertain(RuntimeError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def write_json(path: Path, obj) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def require_file(path: Path, sha: str | None = None, size: int | None = None) -> None:
    if not path.is_file():
        raise StopBeforeMutation(f"falta archivo: {path}")
    if sha is not None and sha256_file(path) != sha:
        raise StopBeforeMutation(f"hash drift: {path}")
    if size is not None and path.stat().st_size != size:
        raise StopBeforeMutation(f"bytes drift: {path}")


def run(cmd: list[str], *, input_text: str | None = None, check: bool = True) -> subprocess.CompletedProcess:
    p = subprocess.run(
        cmd,
        input=input_text,
        text=True,
        capture_output=True,
    )
    if check and p.returncode != 0:
        raise RuntimeError(
            f"command failed rc={p.returncode}: {' '.join(cmd)}\n"
            f"stderr={p.stderr[:4000]}"
        )
    return p


def run_bytes(cmd: list[str], *, input_bytes: bytes | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, input=input_bytes, capture_output=True)


def capture_api_json(
    endpoint: str,
    out_dir: Path,
    label: str,
    *,
    method: str = "GET",
    body=None,
    api_version: str = API_VERSION,
    invalid_exception=ObservationInvalid,
    run_bytes_fn=run_bytes,
    expected_type: type | tuple[type, ...] = dict,
):
    """Archive exact response bytes and metadata before JSON interpretation."""
    cmd = [
        "gh", "api",
        "-H", "Accept: application/vnd.github+json",
        "-H", f"X-GitHub-Api-Version: {api_version}",
    ]
    if method != "GET":
        cmd += ["--method", method]
    body_bytes = None
    if body is not None:
        cmd += ["--input", "-"]
        body_bytes = json.dumps(body, separators=(",", ":")).encode("utf-8")
    cmd += [endpoint]

    started = utc_now()
    p = run_bytes_fn(cmd, input_bytes=body_bytes)
    finished = utc_now()

    raw_path = out_dir / f"{label}.raw.json"
    stderr_path = out_dir / f"{label}.stderr.bin"
    metadata_path = out_dir / f"{label}.capture.json"
    raw_path.write_bytes(p.stdout)
    stderr_path.write_bytes(p.stderr)
    metadata = {
        "capture_started_at_utc": started,
        "capture_finished_at_utc": finished,
        "requested_api_version": api_version,
        "method": method,
        "endpoint": endpoint,
        "return_code": p.returncode,
        "stdout_sha256": hashlib.sha256(p.stdout).hexdigest(),
        "stdout_bytes": len(p.stdout),
        "stderr_sha256": hashlib.sha256(p.stderr).hexdigest(),
        "stderr_bytes": len(p.stderr),
        "raw_body_file": raw_path.name,
        "stderr_file": stderr_path.name,
    }
    write_json(metadata_path, metadata)

    if p.returncode != 0:
        raise invalid_exception(
            f"GitHub API capture failed rc={p.returncode} endpoint={endpoint}"
        )
    try:
        parsed = json.loads(p.stdout.decode("utf-8")) if p.stdout else None
    except Exception as exc:
        raise invalid_exception(
            f"GitHub API raw response is not valid UTF-8 JSON: {endpoint}: {exc}"
        ) from exc
    if not isinstance(parsed, expected_type):
        expected_name = (
            ",".join(t.__name__ for t in expected_type)
            if isinstance(expected_type, tuple)
            else expected_type.__name__
        )
        raise invalid_exception(
            f"GitHub API response has unexpected JSON type for {endpoint}: "
            f"expected {expected_name}, observed {type(parsed).__name__}"
        )
    write_json(out_dir / f"{label}.derived.json", parsed)
    return parsed


def capture_merge_ref(
    pr_number: int,
    out_dir: Path,
    label: str,
    *,
    run_bytes_fn=run_bytes,
) -> str:
    ref_name = f"refs/pull/{pr_number}/merge"
    cmd = [
        "git",
        "ls-remote",
        "--exit-code",
        "--refs",
        f"https://github.com/{LAB_REPO}.git",
        ref_name,
    ]
    started = utc_now()
    p = run_bytes_fn(cmd)
    finished = utc_now()
    stdout_path = out_dir / f"{label}.stdout.bin"
    stderr_path = out_dir / f"{label}.stderr.bin"
    stdout_path.write_bytes(p.stdout)
    stderr_path.write_bytes(p.stderr)
    write_json(
        out_dir / f"{label}.capture.json",
        {
            "capture_started_at_utc": started,
            "capture_finished_at_utc": finished,
            "command": cmd,
            "return_code": p.returncode,
            "stdout_sha256": hashlib.sha256(p.stdout).hexdigest(),
            "stdout_bytes": len(p.stdout),
            "stderr_sha256": hashlib.sha256(p.stderr).hexdigest(),
            "stderr_bytes": len(p.stderr),
            "expected_ref": ref_name,
            "documented_precondition": MERGE_REF_PRECONDITION,
        },
    )
    if p.returncode != 0:
        raise ObservationInvalid(
            f"PR #{pr_number} merge-ref transport failed rc={p.returncode}"
        )
    try:
        decoded = p.stdout.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ObservationInvalid(
            f"PR #{pr_number} merge-ref stdout not UTF-8"
        ) from exc
    lines = [line for line in decoded.splitlines() if line.strip()]
    if len(lines) != 1:
        raise ObservationInvalid(
            f"PR #{pr_number} merge-ref expected exactly one line; got {len(lines)}"
        )
    parts = lines[0].split("\t")
    if len(parts) != 2 or parts[1] != ref_name:
        raise ObservationInvalid(f"PR #{pr_number} merge-ref response unclassifiable")
    sha = parts[0]
    if not HEX40.fullmatch(sha):
        raise ObservationInvalid(f"PR #{pr_number} merge-ref SHA is not 40-hex")
    return sha


def capture_git_commit(
    sha: str,
    out_dir: Path,
    label: str,
    *,
    capture_api_fn=capture_api_json,
) -> dict:
    return capture_api_fn(
        f"repos/{LAB_REPO}/git/commits/{sha}",
        out_dir,
        label,
        api_version=API_VERSION,
    )


def gh_api(endpoint: str, *, method: str = "GET", body=None, check: bool = True):
    cmd = [
        "gh", "api",
        "-H", "Accept: application/vnd.github+json",
        "-H", f"X-GitHub-Api-Version: {API_VERSION}",
    ]
    if method != "GET":
        cmd += ["--method", method]
    if body is not None:
        cmd += ["--input", "-"]
    cmd += [endpoint]
    p = run(cmd, input_text=(json.dumps(body) if body is not None else None), check=False)
    if check and p.returncode != 0:
        raise RuntimeError(
            f"gh api failed rc={p.returncode} endpoint={endpoint}\n"
            f"stderr={p.stderr[:4000]}"
        )
    if p.returncode != 0:
        return p.returncode, None, p.stderr
    try:
        data = json.loads(p.stdout) if p.stdout.strip() else None
    except json.JSONDecodeError as e:
        if check:
            raise RuntimeError(f"invalid JSON from gh api {endpoint}: {e}")
        return p.returncode, None, p.stderr
    return 0, data, p.stderr


def gh_save(endpoint: str, path: Path, *, method: str = "GET", body=None, check: bool = True):
    rc, data, err = gh_api(endpoint, method=method, body=body, check=check)
    if data is not None:
        write_json(path, data)
    else:
        path.write_text("", encoding="utf-8")
    return rc, data, err


def git_ls_remote(ref: str | None = None) -> dict[str, str]:
    cmd = ["git", "ls-remote", f"https://github.com/{LAB_REPO}.git"]
    if ref:
        cmd.append(ref)
    p = run(cmd)
    out: dict[str, str] = {}
    for line in p.stdout.splitlines():
        if not line.strip():
            continue
        sha, name = line.split("\t", 1)
        out[name] = sha
    return out


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def app_jwt(app_id: int, key: Path) -> str:
    now = int(time.time())
    header = b64url(json.dumps({"typ": "JWT", "alg": "RS256"}, separators=(",", ":")).encode())
    payload = b64url(json.dumps({"iat": now - 60, "exp": now + 600, "iss": str(app_id)}, separators=(",", ":")).encode())
    unsigned = f"{header}.{payload}".encode()
    p = subprocess.run(
        ["openssl", "dgst", "-sha256", "-sign", str(key)],
        input=unsigned,
        capture_output=True,
    )
    if p.returncode != 0:
        raise RuntimeError(f"openssl JWT signing failed for App {app_id}")
    return f"{header.decode() if isinstance(header, bytes) else header}.{payload.decode() if isinstance(payload, bytes) else payload}.{b64url(p.stdout)}"


def http_json(method: str, url: str, token: str, body=None):
    raw_body = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(
        url,
        data=raw_body,
        method=method,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": API_VERSION,
            "User-Agent": "r2-stage-b-lab-v13-evidence",
            **({"Content-Type": "application/json"} if body is not None else {}),
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            raw = resp.read()
            parsed = json.loads(raw.decode()) if raw else None
            return resp.status, parsed
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            parsed = json.loads(raw.decode()) if raw else None
        except Exception:
            parsed = {"decode_failed": True}
        return e.code, parsed


def app_request(app: dict, method: str, path: str, body=None):
    jwt = app_jwt(app["id"], app["key"])
    return http_json(method, "https://api.github.com" + path, jwt, body)


def check_key(app: dict) -> None:
    key = app["key"]
    if not key.is_file() or key.is_symlink():
        raise StopBeforeMutation(f"clave ausente/symlink: {key}")
    if stat.S_IMODE(key.stat().st_mode) != 0o600:
        raise StopBeforeMutation(f"modo de clave != 0600: {key}")
    if stat.S_IMODE(key.parent.stat().st_mode) != 0o700:
        raise StopBeforeMutation(f"modo del directorio de claves != 0700: {key.parent}")
    p = subprocess.run(
        ["openssl", "rsa", "-in", str(key), "-pubout", "-outform", "DER"],
        capture_output=True,
    )
    if p.returncode != 0:
        raise StopBeforeMutation(f"clave RSA inválida: {app['label']}")
    fp = base64.b64encode(hashlib.sha256(p.stdout).digest()).decode()
    if fp != app["fingerprint"]:
        raise StopBeforeMutation(f"fingerprint drift: {app['label']}")


def verify_app_live(app: dict, out_dir: Path, prefix: str) -> None:
    status, app_obj = app_request(app, "GET", "/app")
    if status != 200 or not isinstance(app_obj, dict):
        raise StopBeforeMutation(f"{app['label']} GET /app HTTP {status}")
    safe_app = app_obj
    write_json(out_dir / f"{prefix}_app.json", safe_app)

    expected_perm = {"checks": "write", "metadata": "read", "statuses": "write"}
    if app_obj.get("id") != app["id"]:
        raise StopBeforeMutation(f"{app['label']} app.id drift")
    if app_obj.get("slug") != app["slug"]:
        raise StopBeforeMutation(f"{app['label']} slug drift")
    if (app_obj.get("owner") or {}).get("login") != OWNER:
        raise StopBeforeMutation(f"{app['label']} owner drift")
    if app_obj.get("permissions") != expected_perm:
        raise StopBeforeMutation(f"{app['label']} permissions drift")
    if app_obj.get("events") != []:
        raise StopBeforeMutation(f"{app['label']} events drift")

    status, installs = app_request(app, "GET", "/app/installations?per_page=100")
    if status != 200 or not isinstance(installs, list):
        raise StopBeforeMutation(f"{app['label']} installations HTTP {status}")
    write_json(out_dir / f"{prefix}_installations.json", installs)
    if len(installs) != 1:
        raise StopBeforeMutation(f"{app['label']} installation count != 1")
    inst = installs[0]
    if inst.get("id") != app["installation_id"]:
        raise StopBeforeMutation(f"{app['label']} installation_id drift")
    if inst.get("app_id") != app["id"]:
        raise StopBeforeMutation(f"{app['label']} installation app_id drift")
    if inst.get("repository_selection") != "selected":
        raise StopBeforeMutation(f"{app['label']} repository_selection drift")
    if inst.get("permissions") != expected_perm:
        raise StopBeforeMutation(f"{app['label']} installation permissions drift")
    if inst.get("events") != []:
        raise StopBeforeMutation(f"{app['label']} installation events drift")
    if inst.get("suspended_at") is not None:
        raise StopBeforeMutation(f"{app['label']} installation suspended")

    lab_status, lab_map = app_request(app, "GET", f"/repos/{LAB_REPO}/installation")
    prod_status, prod_map = app_request(app, "GET", f"/repos/{PROD_REPO}/installation")
    write_json(out_dir / f"{prefix}_lab_mapping.json", {"http_status": lab_status, "body": lab_map})
    write_json(out_dir / f"{prefix}_prod_mapping.json", {"http_status": prod_status, "body": prod_map})
    if lab_status != 200 or not isinstance(lab_map, dict) or lab_map.get("id") != app["installation_id"]:
        raise StopBeforeMutation(f"{app['label']} lab mapping drift")
    if prod_status != 404:
        raise StopBeforeMutation(f"{app['label']} production mapping != 404")


def make_installation_token(app: dict, out_dir: Path, prefix: str) -> str:
    body = {
        "repositories": [LAB_REPO_NAME],
        "permissions": {"checks": "write"},
    }
    status, obj = app_request(
        app,
        "POST",
        f"/app/installations/{app['installation_id']}/access_tokens",
        body,
    )
    if status != 201 or not isinstance(obj, dict) or not isinstance(obj.get("token"), str):
        raise ObservationInvalid(f"{app['label']} installation-token HTTP {status}")
    token = obj.pop("token")
    write_json(out_dir / f"{prefix}_installation_token_metadata_redacted.json", obj)

    repo_status, repos = http_json(
        "GET",
        "https://api.github.com/installation/repositories?per_page=100",
        token,
    )
    if repo_status != 200 or not isinstance(repos, dict):
        token = ""
        raise ObservationInvalid(f"{app['label']} token repository enumeration HTTP {repo_status}")
    write_json(out_dir / f"{prefix}_installation_repositories.json", repos)
    names = sorted(
        r.get("full_name")
        for r in (repos.get("repositories") or [])
        if isinstance(r, dict)
    )
    if repos.get("total_count") != 1 or names != [LAB_REPO]:
        token = ""
        raise ObservationInvalid(f"{app['label']} runtime token scope not exact lab-only: {names!r}")
    return token


def create_app_check(app: dict, head_sha: str, out_dir: Path, prefix: str) -> dict:
    token = make_installation_token(app, out_dir, prefix)
    body = {
        "name": CONTEXT,
        "head_sha": head_sha,
        "status": "completed",
        "conclusion": "success",
    }
    status, check = http_json(
        "POST",
        f"https://api.github.com/repos/{LAB_REPO}/check-runs",
        token,
        body,
    )
    token = ""
    if status != 201 or not isinstance(check, dict):
        raise ObservationInvalid(f"{app['label']} create check HTTP {status}")
    write_json(out_dir / f"{prefix}_created_check_run.json", check)

    if check.get("name") != CONTEXT:
        raise ObservationInvalid(f"{app['label']} check name mismatch")
    if check.get("head_sha") != head_sha:
        raise ObservationInvalid(f"{app['label']} check head_sha mismatch")
    if check.get("status") != "completed" or check.get("conclusion") != "success":
        raise ObservationInvalid(f"{app['label']} check terminal state mismatch")
    if (check.get("app") or {}).get("id") != app["id"]:
        raise ObservationInvalid(f"{app['label']} check app.id mismatch")
    if not isinstance(check.get("id"), int):
        raise ObservationInvalid(f"{app['label']} check_run.id missing")
    return check


def verify_ruleset_free(branch: str, out_dir: Path, label: str) -> None:
    rc, all_rulesets, err = gh_save(
        f"repos/{LAB_REPO}/rulesets?includes_parents=true&per_page=100",
        out_dir / f"{label}_all_rulesets.json",
        check=False,
    )
    if rc != 0 or all_rulesets != []:
        raise StopBeforeMutation(f"{branch}: rulesets not exact empty")

    encoded = urllib.parse.quote(branch, safe="")
    rc, layered, err = gh_save(
        f"repos/{LAB_REPO}/rules/branches/{encoded}",
        out_dir / f"{label}_layered_rules.json",
        check=False,
    )
    if rc != 0 or layered != []:
        raise StopBeforeMutation(f"{branch}: layered rules not exact empty")

    rc, protection, err = gh_save(
        f"repos/{LAB_REPO}/branches/{encoded}/protection",
        out_dir / f"{label}_classic_protection.json",
        check=False,
    )
    (out_dir / f"{label}_classic_protection_stderr.txt").write_text(err or "", encoding="utf-8")
    # Expected absence: gh exits nonzero and GitHub says 404 / not protected.
    if rc == 0:
        raise StopBeforeMutation(f"{branch}: classic branch protection unexpectedly present")
    if "404" not in (err or "") and "Branch not protected" not in (err or "") and "Not Found" not in (err or ""):
        raise StopBeforeMutation(f"{branch}: classic protection absence unreadable/unclassifiable")


def acquire_test_merge(
    pr_number: int,
    expected_base_sha: str,
    expected_head_sha: str,
    out_dir: Path,
    prefix: str,
    *,
    capture_pr_fn=capture_api_json,
    capture_ref_fn=capture_merge_ref,
    capture_commit_fn=capture_git_commit,
    sleep_fn=time.sleep,
    exhaustion_exception=AcquisitionUninformativeUncertain,
) -> dict:
    for i in range(1, ACQUISITION_MAX_POLLS + 1):
        pr = capture_pr_fn(
            f"repos/{LAB_REPO}/pulls/{pr_number}",
            out_dir,
            f"{prefix}_pr_poll_{i:02d}",
            api_version=API_VERSION,
        )
        if pr.get("state") != "open":
            raise ObservationInvalid(
                f"PR #{pr_number} not open during TEST_MERGE acquisition"
            )
        if (pr.get("base") or {}).get("sha") != expected_base_sha:
            raise ObservationInvalid(f"PR #{pr_number} base SHA drift")
        if (pr.get("head") or {}).get("sha") != expected_head_sha:
            raise ObservationInvalid(f"PR #{pr_number} head SHA drift")

        mergeable = pr.get("mergeable")
        if mergeable is None:
            sleep_fn(ACQUISITION_DELAY_SECONDS)
            if i == ACQUISITION_MAX_POLLS:
                raise exhaustion_exception(
                    f"PR #{pr_number} mergeable remained null after "
                    f"{ACQUISITION_MAX_POLLS} polls x "
                    f"{ACQUISITION_DELAY_SECONDS} seconds"
                )
            continue
        if mergeable is False:
            raise ObservationInvalid(
                f"PR #{pr_number} mergeable=false; conflict_exception=NONE"
            )
        if mergeable is not True:
            raise ObservationInvalid(
                f"PR #{pr_number} mergeable has unexpected value: {mergeable!r}"
            )

        merge_sha = capture_ref_fn(
            pr_number,
            out_dir,
            f"{prefix}_merge_ref",
        )
        if not isinstance(merge_sha, str) or not HEX40.fullmatch(merge_sha):
            raise ObservationInvalid(
                f"PR #{pr_number} merge-ref acquisition returned invalid SHA"
            )
        commit = capture_commit_fn(
            merge_sha,
            out_dir,
            f"{prefix}_test_merge_commit",
        )
        parents = [p.get("sha") for p in (commit.get("parents") or [])]
        if parents != [expected_base_sha, expected_head_sha]:
            raise ObservationInvalid(
                f"PR #{pr_number} TEST_MERGE parents unexpected: {parents!r}"
            )

        post = capture_pr_fn(
            f"repos/{LAB_REPO}/pulls/{pr_number}",
            out_dir,
            f"{prefix}_post_acquisition_pr",
            api_version=API_VERSION,
        )
        if post.get("state") != "open":
            raise ObservationInvalid(
                f"PR #{pr_number} state drift after TEST_MERGE acquisition"
            )
        if (post.get("base") or {}).get("sha") != expected_base_sha:
            raise ObservationInvalid(
                f"PR #{pr_number} base drift after TEST_MERGE acquisition"
            )
        if (post.get("head") or {}).get("sha") != expected_head_sha:
            raise ObservationInvalid(
                f"PR #{pr_number} head drift after TEST_MERGE acquisition"
            )
        return {"pr": post, "test_merge": merge_sha, "commit": commit}

    raise AssertionError("bounded acquisition loop exhausted without terminal branch")


def poll_native_actions(
    pr_number: int,
    source_branch: str,
    manifest_path: str,
    pr_head: str,
    test_merge: str,
    out_dir: Path,
    prefix: str,
):
    deadline = time.monotonic() + 600
    poll_no = 0
    last_reason = "ABSENT"
    while time.monotonic() <= deadline:
        poll_no += 1
        rc, runs, err = gh_api(
            f"repos/{LAB_REPO}/actions/runs?event=pull_request&per_page=100"
        )
        if rc != 0 or not isinstance(runs, dict):
            raise ObservationInvalid("Actions runs read failed")
        write_json(out_dir / f"{prefix}_runs_poll_{poll_no:03d}.json", runs)

        matches = []
        for r in runs.get("workflow_runs") or []:
            if r.get("event") != "pull_request":
                continue
            if r.get("path") != manifest_path:
                continue
            prs = r.get("pull_requests") or []
            pr_numbers = [x.get("number") for x in prs if isinstance(x, dict)]
            if pr_number in pr_numbers:
                matches.append(r)
                continue
            # GitHub can omit pull_requests in some run payloads. In that case,
            # only accept the exact registered source branch as fallback identity.
            if not prs and r.get("head_branch") == source_branch:
                matches.append(r)

        if len(matches) > 1:
            raise ObservationInvalid(
                f"multiple native workflow runs attributable to PR #{pr_number}"
            )
        if not matches:
            last_reason = "ABSENT"
            time.sleep(15)
            continue

        wr = matches[0]
        write_json(out_dir / f"{prefix}_workflow_run_selected.json", wr)
        run_id = wr.get("id")
        if not isinstance(run_id, int):
            raise ObservationInvalid("workflow run id missing")

        rc, jobs, err = gh_api(
            f"repos/{LAB_REPO}/actions/runs/{run_id}/jobs?filter=latest&per_page=100"
        )
        if rc != 0 or not isinstance(jobs, dict):
            raise ObservationInvalid("workflow jobs read failed")
        write_json(out_dir / f"{prefix}_jobs_poll_{poll_no:03d}.json", jobs)

        exact_jobs = [
            j for j in (jobs.get("jobs") or [])
            if j.get("name") == CONTEXT
        ]
        if len(exact_jobs) > 1:
            raise ObservationInvalid(
                "multiple exact native jobs for registered context"
            )
        if not exact_jobs:
            last_reason = "ABSENT_JOB"
            time.sleep(15)
            continue

        job = exact_jobs[0]
        status = job.get("status")
        conclusion = job.get("conclusion")
        if status != "completed":
            last_reason = f"PENDING:{status}"
            time.sleep(15)
            continue

        head_sha = job.get("head_sha")
        if not isinstance(head_sha, str) or not HEX40.fullmatch(head_sha):
            raise ObservationInvalid("native job head_sha absent/invalid")

        # Freeze the exact native check object even for a registered recovery
        # outcome such as OTHER_SHA or wrong conclusion.
        rc, checks, err = gh_api(
            f"repos/{LAB_REPO}/commits/{head_sha}/check-runs?filter=latest&per_page=100"
        )
        if rc != 0 or not isinstance(checks, dict):
            raise ObservationInvalid("native check-runs read failed")
        write_json(out_dir / f"{prefix}_native_head_check_runs.json", checks)

        native = [
            c for c in (checks.get("check_runs") or [])
            if c.get("name") == CONTEXT
            and (c.get("app") or {}).get("slug") == "github-actions"
        ]
        if len(native) > 1:
            raise ObservationInvalid(
                f"multiple native exact check-runs on {head_sha}"
            )
        if not native:
            last_reason = "CHECK_RUN_ABSENT_AFTER_COMPLETED_JOB"
            time.sleep(15)
            continue

        check = native[0]
        write_json(out_dir / f"{prefix}_native_check_run_selected.json", check)
        if check.get("head_sha") != head_sha:
            raise ObservationInvalid(
                "native check_run.head_sha != job.head_sha"
            )
        if not isinstance(check.get("id"), int):
            raise ObservationInvalid("native check_run.id missing")
        if not isinstance((check.get("app") or {}).get("id"), int):
            raise ObservationInvalid("native check app.id missing")

        if conclusion != "success":
            return {
                "kind": "RECOVERY",
                "reason": f"COMPLETED_WRONG_CONCLUSION:{conclusion}",
                "workflow_run": wr,
                "job": job,
                "check": check,
            }
        if (
            check.get("status") != "completed"
            or check.get("conclusion") != "success"
        ):
            return {
                "kind": "RECOVERY",
                "reason": (
                    "NATIVE_CHECK_WRONG_TERMINAL_STATE:"
                    f"{check.get('status')}:{check.get('conclusion')}"
                ),
                "workflow_run": wr,
                "job": job,
                "check": check,
            }

        if head_sha == test_merge:
            binding = "BINDING_TEST_MERGE"
        elif head_sha == pr_head:
            binding = "BINDING_PR_HEAD"
        else:
            return {
                "kind": "RECOVERY",
                "reason": f"BINDING_OTHER_SHA:{head_sha}",
                "workflow_run": wr,
                "job": job,
                "check": check,
            }

        return {
            "kind": "VALID",
            "binding": binding,
            "workflow_run": wr,
            "job": job,
            "check": check,
        }

    return {
        "kind": "RECOVERY",
        "reason": f"ABSENT_OR_PENDING_AFTER_600S:{last_reason}",
    }

def actor_readback(out_dir: Path, filename: str) -> dict:
    rc, actor, err = gh_api("user")
    if rc != 0 or not isinstance(actor, dict):
        raise ObservationInvalid("human actor readback failed")
    write_json(out_dir / filename, actor)
    if actor.get("login") != OWNER or actor.get("id") != 221430316:
        raise ObservationInvalid("human actor identity drift")
    return actor


def close_pr_terminal(
    pr_number: int,
    expected_head: str,
    expected_base: str,
    out_dir: Path,
    prefix: str,
    actor_before: dict,
) -> dict:
    actor = actor_readback(out_dir, f"{prefix}_actor_before_close.json")
    if actor.get("id") != actor_before.get("id") or actor.get("login") != actor_before.get("login"):
        raise StopAfterMutation("human actor drift before PR terminal close")

    pr_now = capture_api_json(
        f"repos/{LAB_REPO}/pulls/{pr_number}",
        out_dir,
        f"{prefix}_pr_before_close",
        invalid_exception=StopAfterMutation,
    )
    if pr_now.get("state") != "open":
        raise StopAfterMutation("PR is not open at terminal close")
    if pr_now.get("merged") is True or pr_now.get("merged_at") is not None:
        raise StopAfterMutation("PR unexpectedly merged before close")
    if (pr_now.get("head") or {}).get("sha") != expected_head:
        raise StopAfterMutation("PR head drift before close")
    if (pr_now.get("base") or {}).get("sha") != expected_base:
        raise StopAfterMutation("PR base drift before close")

    closed = capture_api_json(
        f"repos/{LAB_REPO}/pulls/{pr_number}",
        out_dir,
        f"{prefix}_close_response",
        method="PATCH",
        body={"state": "closed"},
        invalid_exception=StopAfterMutation,
    )
    final = capture_api_json(
        f"repos/{LAB_REPO}/pulls/{pr_number}",
        out_dir,
        f"{prefix}_pr_after_close",
        invalid_exception=StopAfterMutation,
    )
    if final.get("state") != "closed":
        raise StopAfterMutation("terminal PR not closed")
    if final.get("merged") is True or final.get("merged_at") is not None:
        raise StopAfterMutation("terminal PR merged")
    if (final.get("head") or {}).get("sha") != expected_head:
        raise StopAfterMutation("terminal PR head changed")
    if (final.get("base") or {}).get("sha") != expected_base:
        raise StopAfterMutation("terminal PR base changed")
    return final


def freeze_single_surface(sha: str, out_dir: Path, prefix: str) -> None:
    rc, checks, err = gh_api(
        f"repos/{LAB_REPO}/commits/{sha}/check-runs?filter=latest&per_page=100"
    )
    if rc != 0 or not isinstance(checks, dict):
        raise ObservationInvalid("freeze single-surface check-runs failed")
    write_json(out_dir / f"{prefix}_all_check_runs.json", checks)
    rc, statuses, err = gh_api(f"repos/{LAB_REPO}/commits/{sha}/status")
    if rc != 0 or not isinstance(statuses, dict):
        raise ObservationInvalid("freeze single-surface statuses failed")
    write_json(out_dir / f"{prefix}_all_statuses.json", statuses)


def freeze_candidate_surfaces(
    pr_number: int,
    pr_head: str,
    test_merge: str,
    out_dir: Path,
    prefix: str,
):
    for label, sha in [("PR_HEAD", pr_head), ("TEST_MERGE", test_merge)]:
        rc, checks, err = gh_api(
            f"repos/{LAB_REPO}/commits/{sha}/check-runs?filter=latest&per_page=100"
        )
        if rc != 0 or not isinstance(checks, dict):
            raise ObservationInvalid(f"freeze check-runs failed: {label}")
        write_json(out_dir / f"{prefix}_{label}_all_check_runs.json", checks)

        rc, statuses, err = gh_api(f"repos/{LAB_REPO}/commits/{sha}/status")
        if rc != 0 or not isinstance(statuses, dict):
            raise ObservationInvalid(f"freeze statuses failed: {label}")
        write_json(out_dir / f"{prefix}_{label}_all_statuses.json", statuses)
    return


def final_validate_checks(
    pr_head: str,
    test_merge: str,
    native: dict,
    expected_check: dict,
    wrong_check: dict,
    out_dir: Path,
    prefix: str,
):
    frozen = {}
    for label, sha in [("PR_HEAD", pr_head), ("TEST_MERGE", test_merge)]:
        checks = json.loads((out_dir / f"{prefix}_{label}_all_check_runs.json").read_text())
        statuses = json.loads((out_dir / f"{prefix}_{label}_all_statuses.json").read_text())
        frozen[label] = {"checks": checks, "statuses": statuses}

        if statuses.get("statuses") != []:
            raise ObservationInvalid(f"{label} has unexpected commit statuses")

    all_checks = []
    for label in ("PR_HEAD", "TEST_MERGE"):
        for c in frozen[label]["checks"].get("check_runs") or []:
            all_checks.append((label, c))

    # This case starts from a clean no-check/no-status surface; after execution the
    # only modeled check runs on the candidate commits are the one exact native
    # GitHub Actions job and the two App checks on PR_HEAD.
    modeled_ids = {
        native["check"]["id"],
        expected_check["id"],
        wrong_check["id"],
    }
    observed_ids = {c.get("id") for _, c in all_checks}
    if observed_ids != modeled_ids:
        extra = sorted(x for x in observed_ids if x not in modeled_ids)
        missing = sorted(x for x in modeled_ids if x not in observed_ids)
        raise ObservationInvalid(f"candidate check-run set not exact; extra={extra} missing={missing}")

    if expected_check.get("head_sha") != pr_head or wrong_check.get("head_sha") != pr_head:
        raise ObservationInvalid("App check not bound to exact PR_HEAD")

    native_sha = native["check"].get("head_sha")
    if native["binding"] == "BINDING_PR_HEAD" and native_sha != pr_head:
        raise ObservationInvalid("native binding enum/sha contradiction PR_HEAD")
    if native["binding"] == "BINDING_TEST_MERGE" and native_sha != test_merge:
        raise ObservationInvalid("native binding enum/sha contradiction TEST_MERGE")

    ids = [
        (native["check"].get("app") or {}).get("id"),
        (expected_check.get("app") or {}).get("id"),
        (wrong_check.get("app") or {}).get("id"),
    ]
    if len(set(ids)) != 3:
        raise ObservationInvalid(f"producer app IDs not distinct: {ids!r}")
    if ids[1] != EXPECTED_APP["id"] or ids[2] != WRONG_APP["id"]:
        raise ObservationInvalid("App producer IDs mismatch")
    if ids[0] in (EXPECTED_APP["id"], WRONG_APP["id"]):
        raise ObservationInvalid("native Actions producer collided with lab App ID")

    return {
        "native_app_id": ids[0],
        "native_check_run_id": native["check"]["id"],
        "native_check_suite_id": (native["check"].get("check_suite") or {}).get("id"),
        "expected_app_check_run_id": expected_check["id"],
        "expected_app_check_suite_id": (expected_check.get("check_suite") or {}).get("id"),
        "wrong_app_check_run_id": wrong_check["id"],
        "wrong_app_check_suite_id": (wrong_check.get("check_suite") or {}).get("id"),
    }


def validate_static_inputs() -> dict:
    exact_inputs = [
        (DESIGN, DESIGN_SHA, DESIGN_BYTES),
        (REVIEW, REVIEW_SHA, REVIEW_BYTES),
        (V14_V2, V14_V2_SHA, V14_V2_BYTES),
        (HARNESS_SPEC, HARNESS_SPEC_SHA, HARNESS_SPEC_BYTES),
        (FORENSICS, FORENSICS_SHA, FORENSICS_BYTES),
        (V14_V2_REVIEW, V14_V2_REVIEW_SHA, V14_V2_REVIEW_BYTES),
        (HISTORICAL_STOP, HISTORICAL_STOP_SHA, HISTORICAL_STOP_BYTES),
        (WRONG_INSTALL_RESULT, WRONG_INSTALL_RESULT_SHA, WRONG_INSTALL_RESULT_BYTES),
    ]
    for path, sha, size in exact_inputs:
        require_file(path, sha, size)
    for app in LAB_APPS:
        check_key(app)

    design = json.loads(DESIGN.read_text(encoding="utf-8"))
    review = json.loads(REVIEW.read_text(encoding="utf-8"))
    v14 = json.loads(V14_V2.read_text(encoding="utf-8"))
    harness = json.loads(HARNESS_SPEC.read_text(encoding="utf-8"))
    forensics = json.loads(FORENSICS.read_text(encoding="utf-8"))
    v14_review = json.loads(V14_V2_REVIEW.read_text(encoding="utf-8"))
    historical_stop = json.loads(HISTORICAL_STOP.read_text(encoding="utf-8"))
    previous = json.loads(WRONG_INSTALL_RESULT.read_text(encoding="utf-8"))

    disposition = review.get("design_disposition") or {}
    if disposition.get("verdict") != "TECHNICAL_PASS_LAB_DESIGN_ONLY":
        raise StopBeforeMutation("review V5 no longer exact technical PASS")
    if disposition.get("blocking_findings_count") != 0:
        raise StopBeforeMutation("review V5 blockers != 0")

    if v14.get("artifact_type") != "r2-4-stage-b-platform-semantics-lab-design-v14-delta-v2":
        raise StopBeforeMutation("V14-v2 artifact type drift")
    if (v14.get("authority") or {}).get("execution_authority") != "NONE":
        raise StopBeforeMutation("V14-v2 authority drift")
    acquisition = v14.get("test_merge_acquisition_override") or {}
    if acquisition.get("API_version_for_PR_state") != API_VERSION:
        raise StopBeforeMutation("V14-v2 API version drift")
    if acquisition.get("max_attempts") != ACQUISITION_MAX_POLLS:
        raise StopBeforeMutation("V14-v2 acquisition budget drift")
    if acquisition.get("delay_seconds") != ACQUISITION_DELAY_SECONDS:
        raise StopBeforeMutation("V14-v2 acquisition delay drift")
    merge_field = acquisition.get("merge_commit_sha_field") or {}
    if merge_field.get("may_be_used_as_evidence_under_2026_03_10") is not False:
        raise StopBeforeMutation("V14-v2 removed-field rule drift")
    continuation = v14.get("LAB_ID_OBSERVATION_continuation") or {}
    if (continuation.get("attempt_1") or {}).get("disposition") != HISTORICAL_ATTEMPT_1_DISPOSITION:
        raise StopBeforeMutation("historical attempt-1 disposition drift")
    remaining = continuation.get("remaining_attempt") or {}
    if remaining.get("attempt") != 2 or remaining.get("remaining_attempt_budget") != 1:
        raise StopBeforeMutation("remaining attempt budget drift")
    if remaining.get("target") != ATTEMPT["target"] or remaining.get("source") != ATTEMPT["source"]:
        raise StopBeforeMutation("remaining attempt identity drift")

    if harness.get("artifact_type") != "r2-4-stage-b-v14-harness-correction-spec":
        raise StopBeforeMutation("harness spec artifact type drift")
    semantics = harness.get("required_code_semantics") or {}
    if semantics.get("keep_global_API_VERSION") != API_VERSION:
        raise StopBeforeMutation("harness API version drift")
    if semantics.get("remove_load_bearing_dependency_on_merge_commit_sha") is not True:
        raise StopBeforeMutation("harness removed-field requirement drift")
    if semantics.get("attempts") != [2]:
        raise StopBeforeMutation("harness attempt set drift")
    if semantics.get("new_evidence_root") != CASE_DIR.name:
        raise StopBeforeMutation("harness evidence root drift")
    if harness.get("execution_authority") != "NONE":
        raise StopBeforeMutation("harness grants authority")

    if forensics.get("cause_class") != "API_VERSION_2026_FIELD_OMISSION_CONFIRMED":
        raise StopBeforeMutation("forensic root cause drift")
    if forensics.get("github_mutation_performed") is not False:
        raise StopBeforeMutation("forensics mutation flag drift")

    if v14_review.get("artifact_type") != "r2-4-stage-b-v14-v2-independent-review-result":
        raise StopBeforeMutation("V14-v2 review artifact type drift")
    if v14_review.get("review_disposition") != "TECHNICAL_PASS_V14_V2_ONLY":
        raise StopBeforeMutation("V14-v2 review no longer PASS")
    if v14_review.get("blocking_findings") != []:
        raise StopBeforeMutation("V14-v2 review blockers nonempty")
    if v14_review.get("required_changes_before_new_Human_Gate_D") != []:
        raise StopBeforeMutation("V14-v2 required changes nonempty")
    if v14_review.get("V15_required") is not False:
        raise StopBeforeMutation("V14-v2 review requires V15")
    if v14_review.get("execution_authority") != "NONE":
        raise StopBeforeMutation("V14-v2 review authority drift")

    if historical_stop.get("status") != "OBSERVATION_INVALID_STOP":
        raise StopBeforeMutation("historical attempt-1 stop status drift")
    if historical_stop.get("case_outcome") != "OBSERVATION_INVALID":
        raise StopBeforeMutation("historical attempt-1 outcome drift")
    if historical_stop.get("mutation_started") is not True:
        raise StopBeforeMutation("historical attempt-1 mutation flag drift")

    required_prev = {
        "status": "PASS",
        "app_label": "LAB_WRONG_APP",
        "app_id": WRONG_APP["id"],
        "installation_id": WRONG_APP["installation_id"],
        "repository_selection": "selected",
        "accessible_repositories": [LAB_REPO],
        "production_repository_installation_http": 404,
        "LAB_EXPECTED_APP_ID": EXPECTED_APP["id"],
        "LAB_EXPECTED_INSTALLATION_ID": EXPECTED_APP["installation_id"],
        "expected_app_reverified_after_wrong_install": True,
        "both_apps_ready_for_LAB_ID_OBSERVATION": True,
        "production_main_unchanged": True,
        "PR6_unchanged": True,
        "lab_main_unchanged": True,
        "LAB_ID_OBSERVATION_started": False,
    }
    for k, v in required_prev.items():
        if previous.get(k) != v:
            raise StopBeforeMutation(
                f"previous wrong-install result drift {k}={previous.get(k)!r}, expected={v!r}"
            )

    case = (design.get("cases") or {}).get("LAB-ID-OBSERVATION") or {}
    if case.get("type") != "OBSERVATION" or case.get("context") != CONTEXT:
        raise StopBeforeMutation("V13 LAB-ID-OBSERVATION case drift")
    if case.get("signals") != {
        "GitHub_Actions": "TEST_MERGE",
        "LAB_EXPECTED_APP": "PR_HEAD",
        "LAB_WRONG_APP": "PR_HEAD",
    }:
        raise StopBeforeMutation("V13 signal registry drift")
    if (design.get("case_ruleset_instances") or {}).get("LAB-ID-OBSERVATION") != []:
        raise StopBeforeMutation("LAB-ID-OBSERVATION ruleset instances drift")

    recovery = (design.get("Actions_recovery_registry") or {}).get("LAB-ID-OBSERVATION") or {}
    attempts = recovery.get("attempts") or []
    if recovery.get("max_attempts") != 2 or recovery.get("after_cap") != "UNINFORMATIVE_UNCERTAIN":
        raise StopBeforeMutation("V13 recovery cap drift")
    if len(attempts) != 2 or attempts[1] != {
        "target": ATTEMPT["target"],
        "source": ATTEMPT["source"],
        "manifest": ATTEMPT["manifest_id"],
    }:
        raise StopBeforeMutation("V13 attempt-2 recovery registry drift")

    protocol = design.get("native_actions_check_binding_protocol") or {}
    wait = protocol.get("wait") or {}
    if wait.get("max_seconds") != 600 or wait.get("poll_interval_seconds") != 15:
        raise StopBeforeMutation("native Actions bounded wait drift")

    manifests = design.get("workflow_manifests_exact") or {}
    sources = design.get("source_branch_registry") or {}
    profiles = design.get("target_profile_assignment_authoritative") or {}
    target_reg = design.get("target_branch_registry") or {}
    m = manifests.get(ATTEMPT["manifest_id"]) or {}
    raw = (m.get("content_utf8") or "").encode()
    if m.get("path") != ATTEMPT["manifest_path"]:
        raise StopBeforeMutation("attempt-2 manifest path drift")
    if hashlib.sha256(raw).hexdigest() != ATTEMPT["manifest_sha256"] or len(raw) != ATTEMPT["manifest_bytes"]:
        raise StopBeforeMutation("attempt-2 manifest bytes/hash drift")
    if m.get("trigger") != "pull_request" or m.get("job_display_name") != CONTEXT:
        raise StopBeforeMutation("attempt-2 workflow trigger/job drift")
    if profiles.get(ATTEMPT["target"]) != "ACTIONS_CHECK":
        raise StopBeforeMutation("attempt-2 target profile drift")
    s = sources.get(ATTEMPT["source"]) or {}
    if s.get("target") != ATTEMPT["target"] or s.get("case_id") != "LAB-ID-OBSERVATION":
        raise StopBeforeMutation("attempt-2 source registry drift")

    expected_heads = set(target_reg) | set(sources)
    if len(target_reg) != 35 or len(sources) != 26 or len(expected_heads) != 61:
        raise StopBeforeMutation("V13 branch registry counts drift")

    return {
        "design": design,
        "v14": v14,
        "harness": harness,
        "v14_review": v14_review,
        "expected_heads": expected_heads,
    }


def preflight(static: dict) -> None:
    p = run(["gh", "auth", "status"], check=False)
    (CASE_DIR / "gh_auth_status.txt").write_text(p.stdout + p.stderr, encoding="utf-8")
    if p.returncode != 0:
        raise StopBeforeMutation("gh no autenticado")
    actor_readback(CASE_DIR, "preflight_actor.json")

    rc, prod, err = gh_save(
        f"repos/{PROD_REPO}/commits/main", CASE_DIR / "preflight_prod_main.json"
    )
    if prod.get("sha") != EXPECTED_PROD_MAIN:
        raise StopBeforeMutation("production main drift")

    pr6 = capture_api_json(
        f"repos/{PROD_REPO}/pulls/6",
        CASE_DIR,
        "preflight_pr6",
        invalid_exception=StopBeforeMutation,
    )
    if (
        pr6.get("state") != "open"
        or pr6.get("merged") is not False
        or (pr6.get("head") or {}).get("sha") != EXPECTED_PR6_HEAD
        or (pr6.get("base") or {}).get("sha") != EXPECTED_PROD_MAIN
    ):
        raise StopBeforeMutation("production PR6 drift")

    rc, state_meta, err = gh_save(
        f"repos/{PROD_REPO}/contents/R2_STATE.md?ref={EXPECTED_PROD_MAIN}",
        CASE_DIR / "preflight_state.json",
    )
    if state_meta.get("sha") != EXPECTED_STATE_BLOB:
        raise StopBeforeMutation("R2_STATE blob drift")
    try:
        state_text = base64.b64decode(state_meta["content"]).decode()
    except Exception as exc:
        raise StopBeforeMutation(f"R2_STATE decode failed: {exc}") from exc
    for marker in [
        "FALSE_GREENS: 8 total.",
        "DC-006: OPEN.",
        "EXP-01: OPEN.",
        "IR2-002: BLOCKING_BEFORE_FIRST_FUNCTIONAL_TASK.",
        "REQUIRED_CHECK: NOT_CONFIGURED.",
        "BRANCH_PROTECTION/NO-BYPASS: NOT_CONFIGURED.",
        "MINOR-5: ACTIVE_R2-4_NOT_EXECUTED.",
        "ENFORCED: False.",
        "R2-4 exit gate: NOT_EXECUTED",
        "R2-5: NOT_AUTHORIZED.",
    ]:
        if marker not in state_text:
            raise StopBeforeMutation(f"R2_STATE marker missing: {marker}")

    rc, lab_repo, err = gh_save(f"repos/{LAB_REPO}", CASE_DIR / "preflight_lab_repo.json")
    if (
        lab_repo.get("full_name") != LAB_REPO
        or lab_repo.get("visibility") != "public"
        or lab_repo.get("private") is not False
        or lab_repo.get("fork") is not False
        or lab_repo.get("default_branch") != "main"
    ):
        raise StopBeforeMutation("lab repository identity/config drift")

    rc, lab_main, err = gh_save(
        f"repos/{LAB_REPO}/commits/main", CASE_DIR / "preflight_lab_main.json"
    )
    if lab_main.get("sha") != EXPECTED_LAB_MAIN:
        raise StopBeforeMutation("lab main harness drift")

    prs = capture_api_json(
        f"repos/{LAB_REPO}/pulls?state=all&per_page=100",
        CASE_DIR,
        "preflight_lab_prs",
        invalid_exception=StopBeforeMutation,
        expected_type=list,
    )
    if not isinstance(prs, list) or len(prs) != 1:
        raise StopBeforeMutation("lab PR inventory must contain only historical PR #1")
    pr1 = prs[0]
    if (
        pr1.get("number") != 1
        or pr1.get("state") != "closed"
        or pr1.get("merged") is True
        or pr1.get("merged_at") is not None
        or (pr1.get("base") or {}).get("sha") != HISTORICAL_ATTEMPT_1["target_sha"]
        or (pr1.get("head") or {}).get("sha") != HISTORICAL_ATTEMPT_1["source_sha"]
    ):
        raise StopBeforeMutation("historical PR #1 drift")
    if any(pr.get("number") == 2 for pr in prs):
        raise StopBeforeMutation("PR #2 already exists")

    rc, runs, err = gh_save(
        f"repos/{LAB_REPO}/actions/runs?per_page=100", CASE_DIR / "preflight_lab_runs.json"
    )
    workflow_runs = runs.get("workflow_runs") or []
    for wr in workflow_runs:
        if wr.get("path") != HISTORICAL_ATTEMPT_1["manifest_path"] or wr.get("event") != "pull_request":
            raise StopBeforeMutation(f"unexpected historical workflow run {wr.get('id')}")
        if wr.get("head_branch") != HISTORICAL_ATTEMPT_1["source"]:
            raise StopBeforeMutation(f"historical workflow source drift {wr.get('id')}")

    rc, rulesets, err = gh_save(
        f"repos/{LAB_REPO}/rulesets?includes_parents=true&per_page=100",
        CASE_DIR / "preflight_lab_rulesets.json",
    )
    if rulesets != []:
        raise StopBeforeMutation("lab rulesets no longer empty")

    refs = git_ls_remote("refs/heads/*")
    heads = {k.removeprefix("refs/heads/"): v for k, v in refs.items()}
    write_json(CASE_DIR / "preflight_heads.json", heads)
    if set(heads) != static["expected_heads"] or len(heads) != 61:
        raise StopBeforeMutation("lab head registry/set drift")
    if heads.get("main") != EXPECTED_LAB_MAIN:
        raise StopBeforeMutation("lab main ref drift")
    if heads.get(ATTEMPT["target"]) != ATTEMPT["target_sha"]:
        raise StopBeforeMutation("attempt-2 target SHA drift")
    if heads.get(ATTEMPT["source"]) != ATTEMPT["source_sha"]:
        raise StopBeforeMutation("attempt-2 source SHA drift")

    tags = git_ls_remote("refs/tags/*")
    write_json(CASE_DIR / "preflight_tags.json", tags)
    if tags:
        raise StopBeforeMutation("unexpected lab tags")

    for role, branch in [("target", ATTEMPT["target"]), ("source", ATTEMPT["source"])]:
        endpoint = (
            f"repos/{LAB_REPO}/contents/{ATTEMPT['manifest_path']}"
            f"?ref={urllib.parse.quote(branch, safe='')}"
        )
        rc, content_obj, err = gh_api(endpoint)
        if rc != 0 or not isinstance(content_obj, dict):
            raise StopBeforeMutation(f"attempt-2 workflow content unreadable: {branch}")
        write_json(CASE_DIR / f"attempt2_{role}_workflow_content.json", content_obj)
        raw = base64.b64decode(content_obj.get("content") or "")
        if hashlib.sha256(raw).hexdigest() != ATTEMPT["manifest_sha256"]:
            raise StopBeforeMutation(f"attempt-2 workflow hash drift: {branch}")
        if len(raw) != ATTEMPT["manifest_bytes"]:
            raise StopBeforeMutation(f"attempt-2 workflow bytes drift: {branch}")

    verify_ruleset_free(ATTEMPT["target"], CASE_DIR, "attempt2_rules_preflight")
    for role, sha in [("target", ATTEMPT["target_sha"]), ("source", ATTEMPT["source_sha"])]:
        rc, checks, err = gh_save(
            f"repos/{LAB_REPO}/commits/{sha}/check-runs?filter=latest&per_page=100",
            CASE_DIR / f"attempt2_{role}_precheck_runs.json",
        )
        if checks.get("total_count") != 0 or checks.get("check_runs") != []:
            raise StopBeforeMutation(f"pre-existing check run on attempt-2 {role}")
        rc, statuses, err = gh_save(
            f"repos/{LAB_REPO}/commits/{sha}/status",
            CASE_DIR / f"attempt2_{role}_prestatuses.json",
        )
        if statuses.get("statuses") != []:
            raise StopBeforeMutation(f"pre-existing commit status on attempt-2 {role}")

    verify_app_live(EXPECTED_APP, CASE_DIR, "expected")
    verify_app_live(WRONG_APP, CASE_DIR, "wrong")

    report = {
        "schema_version": 1,
        "artifact_type": "r2-4-stage-b-v14-v2-attempt2-preflight",
        "status": "PASS",
        "production_main": EXPECTED_PROD_MAIN,
        "PR6_head": EXPECTED_PR6_HEAD,
        "lab_main": EXPECTED_LAB_MAIN,
        "head_count": len(heads),
        "historical_PR1": "CLOSED_UNMERGED",
        "PR2_exists": False,
        "historical_attempt_1_disposition": HISTORICAL_ATTEMPT_1_DISPOSITION,
        "remaining_attempt": 2,
        "remaining_attempt_budget": 1,
        "ruleset_count": 0,
        "LAB_EXPECTED_APP_ID": EXPECTED_APP["id"],
        "LAB_EXPECTED_INSTALLATION_ID": EXPECTED_APP["installation_id"],
        "LAB_WRONG_APP_ID": WRONG_APP["id"],
        "LAB_WRONG_INSTALLATION_ID": WRONG_APP["installation_id"],
        "mutation_performed": False,
    }
    write_json(CASE_DIR / "LAB_ID_OBSERVATION_V14_ATTEMPT2_PRE_GATE.json", report)
    print("LAB_ID_OBSERVATION_V14_ATTEMPT2_PRE_GATE_PASS")
    print("HISTORICAL_ATTEMPT_1=CONSUMED_INVALID_CLOSED_UNMERGED")
    print("REMAINING_ATTEMPT=2")
    print("REMAINING_ATTEMPT_BUDGET=1")
    print("PR2_EXISTS=false")


def open_attempt_pr(a: dict, attempt_dir: Path) -> tuple[int, dict, dict]:
    actor = actor_readback(attempt_dir, "actor_before_pr_open.json")
    body = {
        "title": "R2 LAB ID OBSERVATION V14-V2 ATTEMPT 2",
        "head": a["source"],
        "base": a["target"],
        "body": (
            "Disposable V14-v2 LAB-ID-OBSERVATION attempt 2. "
            "Observation only. No merge authorized. Attempt 1 remains consumed."
        ),
    }
    pr = capture_api_json(
        f"repos/{LAB_REPO}/pulls",
        attempt_dir,
        "pr_open_response",
        method="POST",
        body=body,
        invalid_exception=StopAfterMutation,
    )
    number = pr.get("number")
    if number != EXPECTED_NEW_PR_NUMBER:
        raise StopAfterMutation(
            f"created PR number must be exactly {EXPECTED_NEW_PR_NUMBER}; "
            f"observed {number!r}"
        )
    if pr.get("state") != "open":
        raise StopAfterMutation("created PR not open")
    if (pr.get("head") or {}).get("sha") != a["source_sha"]:
        raise StopAfterMutation("created PR head SHA mismatch")
    if (pr.get("base") or {}).get("sha") != a["target_sha"]:
        raise StopAfterMutation("created PR base SHA mismatch")
    if pr.get("merged") is True or pr.get("merged_at") is not None:
        raise StopAfterMutation("created PR unexpectedly merged")
    print(f"ATTEMPT_2_PR_NUMBER={EXPECTED_NEW_PR_NUMBER}")
    print("ATTEMPT_2_PR_OPENED=true")
    return number, pr, actor


def execute_attempt(a: dict) -> dict:
    attempt_no = 2
    if a != ATTEMPT or a.get("number") != 2:
        raise StopBeforeMutation("only pre-registered attempt 2 is executable")
    attempt_dir = CASE_DIR / "attempt_2"
    attempt_dir.mkdir(mode=0o700)

    # Per-case ruleset/protection preflight again immediately before the mutation.
    verify_ruleset_free(
        a["target"],
        attempt_dir,
        "immediate_rules_preflight",
    )

    current_refs = git_ls_remote()
    if current_refs.get(f"refs/heads/{a['target']}") != a["target_sha"]:
        raise StopBeforeMutation(f"attempt {attempt_no} target moved before PR open")
    if current_refs.get(f"refs/heads/{a['source']}") != a["source_sha"]:
        raise StopBeforeMutation(f"attempt {attempt_no} source moved before PR open")
    if current_refs.get("refs/heads/main") != EXPECTED_LAB_MAIN:
        raise StopBeforeMutation("lab main moved before PR open")

    pr_number, opened_pr, actor = open_attempt_pr(a, attempt_dir)

    def terminalize_if_open(prefix: str) -> None:
        """Apply only the pre-registered observation-PR terminal state."""
        pr_now = capture_api_json(
            f"repos/{LAB_REPO}/pulls/{pr_number}",
            attempt_dir,
            f"{prefix}_terminal_state_probe",
            invalid_exception=StopAfterMutation,
        )

        if (
            pr_now.get("state") == "closed"
            and pr_now.get("merged") is not True
            and pr_now.get("merged_at") is None
        ):
            if (pr_now.get("head") or {}).get("sha") != a["source_sha"]:
                raise StopAfterMutation("closed terminal PR head drift")
            if (pr_now.get("base") or {}).get("sha") != a["target_sha"]:
                raise StopAfterMutation("closed terminal PR base drift")
            return

        if (
            pr_now.get("state") == "open"
            and pr_now.get("merged") is not True
            and pr_now.get("merged_at") is None
            and (pr_now.get("head") or {}).get("sha") == a["source_sha"]
            and (pr_now.get("base") or {}).get("sha") == a["target_sha"]
        ):
            close_pr_terminal(
                pr_number,
                a["source_sha"],
                a["target_sha"],
                attempt_dir,
                prefix,
                actor,
            )
            return

        raise StopAfterMutation(
            f"PR #{pr_number} state/head/base is unclassifiable for safe terminal close"
        )

    try:
        acquired = acquire_test_merge(
            pr_number,
            a["target_sha"],
            a["source_sha"],
            attempt_dir,
            "initial",
        )

        test_merge = acquired["test_merge"]
        print(f"ATTEMPT_{attempt_no}_PR_HEAD={a['source_sha']}")
        print(f"ATTEMPT_{attempt_no}_TEST_MERGE={test_merge}")

        native = poll_native_actions(
            pr_number,
            a["source"],
            a["manifest_path"],
            a["source_sha"],
            test_merge,
            attempt_dir,
            "native",
        )

        if native["kind"] == "RECOVERY":
            # Freeze what exists, then terminally close without merge. No App signals
            # are created on a native-invalid attempt.
            freeze_candidate_surfaces(
                pr_number,
                a["source_sha"],
                test_merge,
                attempt_dir,
                "recovery_freeze",
            )
            close_pr_terminal(
                pr_number,
                a["source_sha"],
                a["target_sha"],
                attempt_dir,
                "recovery",
                actor,
            )
            observed_native_check = native.get("check") if isinstance(native, dict) else None
            observed_native_sha = (
                observed_native_check.get("head_sha")
                if isinstance(observed_native_check, dict)
                else None
            )
            if observed_native_sha == test_merge:
                observed_binding = "BINDING_TEST_MERGE"
            elif observed_native_sha == a["source_sha"]:
                observed_binding = "BINDING_PR_HEAD"
            elif isinstance(observed_native_sha, str):
                observed_binding = "BINDING_OTHER_SHA"
            else:
                observed_binding = None

            result = {
                "attempt": attempt_no,
                "pr_number": pr_number,
                "PR_HEAD": a["source_sha"],
                "TEST_MERGE": test_merge,
                "outcome": "OBSERVATION_UNCERTAIN",
                "reason": native["reason"],
                "native_binding": observed_binding,
                "native_check_run_id": (
                    observed_native_check.get("id")
                    if isinstance(observed_native_check, dict)
                    else None
                ),
                "native_app_id": (
                    (observed_native_check.get("app") or {}).get("id")
                    if isinstance(observed_native_check, dict)
                    else None
                ),
                "native_observed_head_sha": observed_native_sha,
                "expected_app_check_created": False,
                "wrong_app_check_created": False,
                "pr_terminal_state": "CLOSED_UNMERGED",
            }
            write_json(attempt_dir / "ATTEMPT_RESULT.json", result)
            print(f"ATTEMPT_{attempt_no}_NATIVE_RESULT={native['reason']}")
            print(f"ATTEMPT_{attempt_no}_OUTCOME={result['outcome']}")
            print(f"ATTEMPT_{attempt_no}_PR_TERMINAL_STATE=CLOSED_UNMERGED")
            return result

        binding = native["binding"]
        print(f"ATTEMPT_{attempt_no}_NATIVE_BINDING={binding}")
        print(f"ATTEMPT_{attempt_no}_NATIVE_CHECK_RUN_ID={native['check']['id']}")
        print(
            f"ATTEMPT_{attempt_no}_NATIVE_APP_ID="
            f"{(native['check'].get('app') or {}).get('id')}"
        )

        # Re-acquire the test merge immediately before App signal mutation and
        # demand exact object stability.
        reacquired = acquire_test_merge(
            pr_number,
            a["target_sha"],
            a["source_sha"],
            attempt_dir,
            "pre_app_signal",
            exhaustion_exception=ObservationInvalid,
        )
        if reacquired["test_merge"] != test_merge:
            freeze_candidate_surfaces(
                pr_number,
                a["source_sha"],
                reacquired["test_merge"],
                attempt_dir,
                "drift_freeze",
            )
            raise ObservationInvalid(
                "TEST_MERGE changed before App signal creation"
            )

        expected_check = create_app_check(
            EXPECTED_APP,
            a["source_sha"],
            attempt_dir,
            "expected_app",
        )
        wrong_check = create_app_check(
            WRONG_APP,
            a["source_sha"],
            attempt_dir,
            "wrong_app",
        )

        # Full evidence freeze after all three producer objects exist.
        final_acquired = acquire_test_merge(
            pr_number,
            a["target_sha"],
            a["source_sha"],
            attempt_dir,
            "final_freeze",
            exhaustion_exception=ObservationInvalid,
        )
        if final_acquired["test_merge"] != test_merge:
            freeze_candidate_surfaces(
                pr_number,
                a["source_sha"],
                final_acquired["test_merge"],
                attempt_dir,
                "final_drift_freeze",
            )
            raise ObservationInvalid(
                "TEST_MERGE changed inside final evidence freeze"
            )

        freeze_candidate_surfaces(
            pr_number,
            a["source_sha"],
            test_merge,
            attempt_dir,
            "final",
        )
        identities = final_validate_checks(
            a["source_sha"],
            test_merge,
            native,
            expected_check,
            wrong_check,
            attempt_dir,
            "final",
        )

        # Rules remain entirely absent throughout this observation.
        # Any drift here occurs after PR/check mutation and is therefore converted
        # below into OBSERVATION_INVALID + exact terminal close.
        verify_ruleset_free(
            a["target"],
            attempt_dir,
            "final_rules_readback",
        )

        close_pr_terminal(
            pr_number,
            a["source_sha"],
            a["target_sha"],
            attempt_dir,
            "complete",
            actor,
        )

        result = {
            "attempt": attempt_no,
            "pr_number": pr_number,
            "target": a["target"],
            "target_sha": a["target_sha"],
            "source": a["source"],
            "PR_HEAD": a["source_sha"],
            "TEST_MERGE": test_merge,
            "outcome": "OBSERVATION_COMPLETE",
            "native_binding": binding,
            **identities,
            "LAB_EXPECTED_APP_ID": EXPECTED_APP["id"],
            "LAB_EXPECTED_INSTALLATION_ID": EXPECTED_APP["installation_id"],
            "LAB_WRONG_APP_ID": WRONG_APP["id"],
            "LAB_WRONG_INSTALLATION_ID": WRONG_APP["installation_id"],
            "expected_app_check_run_id": expected_check["id"],
            "wrong_app_check_run_id": wrong_check["id"],
            "pr_terminal_state": "CLOSED_UNMERGED",
            "rulesets_created": False,
            "merge_performed": False,
        }
        write_json(attempt_dir / "ATTEMPT_RESULT.json", result)

        print(
            f"ATTEMPT_{attempt_no}_EXPECTED_APP_CHECK_RUN_ID="
            f"{expected_check['id']}"
        )
        print(
            f"ATTEMPT_{attempt_no}_WRONG_APP_CHECK_RUN_ID="
            f"{wrong_check['id']}"
        )
        print(f"ATTEMPT_{attempt_no}_OUTCOME=OBSERVATION_COMPLETE")
        print(f"ATTEMPT_{attempt_no}_PR_TERMINAL_STATE=CLOSED_UNMERGED")
        return result

    except AcquisitionUninformativeUncertain as exc:
        terminalize_if_open("acquisition_budget_terminal")
        freeze_single_surface(
            a["source_sha"],
            attempt_dir,
            "acquisition_budget_freeze_PR_HEAD",
        )
        result = {
            "attempt": 2,
            "pr_number": pr_number,
            "target": a["target"],
            "target_sha": a["target_sha"],
            "source": a["source"],
            "PR_HEAD": a["source_sha"],
            "TEST_MERGE": None,
            "outcome": ACQUISITION_EXHAUSTED_OUTCOME,
            "reason": str(exc),
            "pr_terminal_state": "CLOSED_UNMERGED",
            "evidence": "FROZEN",
            "stop_all": True,
            "L2_started": False,
            "merge_performed": False,
        }
        write_json(attempt_dir / "ATTEMPT_RESULT.json", result)
        print("ATTEMPT_2_OUTCOME=UNINFORMATIVE_UNCERTAIN")
        print("ATTEMPT_2_PR_TERMINAL_STATE=CLOSED_UNMERGED")
        print("EVIDENCE=FROZEN")
        print("STOP_ALL=true")
        return result

    except StopAfterMutation:
        raise
    except ObservationInvalid:
        # V13 pre-registers observation PRs as terminal CLOSED_UNMERGED.
        # Apply only that exact terminal mutation when the PR still has its
        # expected base/head and is known unmerged.
        terminalize_if_open("invalid_terminal")
        raise
    except StopBeforeMutation as e:
        # A check coded as "pre" can still be called after the PR/check objects
        # exist. Do not mislabel that state; terminalize the exact PR and convert
        # it to an observation-invalid stop.
        terminalize_if_open("postmutation_invariant_terminal")
        raise ObservationInvalid(
            f"post-mutation invariant/readback failure: {e}"
        ) from e
    except Exception as e:
        # No semantic improvisation: only close the exact registered observation
        # PR if its state is still classifiable, then stop as an after-mutation
        # runtime failure.
        terminalize_if_open("unclassified_terminal")
        raise StopAfterMutation(
            f"unclassified runtime failure after PR creation: "
            f"{type(e).__name__}: {e}"
        ) from e

def postflight(attempt_results: list[dict], case_outcome: str) -> dict:
    rc, prod, err = gh_save(
        f"repos/{PROD_REPO}/commits/main", CASE_DIR / "post_prod_main.json"
    )
    pr6 = capture_api_json(
        f"repos/{PROD_REPO}/pulls/6",
        CASE_DIR,
        "post_pr6",
        invalid_exception=StopAfterMutation,
    )
    rc, lab_main, err = gh_save(
        f"repos/{LAB_REPO}/commits/main", CASE_DIR / "post_lab_main.json"
    )
    prs = capture_api_json(
        f"repos/{LAB_REPO}/pulls?state=all&per_page=100",
        CASE_DIR,
        "post_lab_prs",
        invalid_exception=StopAfterMutation,
        expected_type=list,
    )
    rc, runs, err = gh_save(
        f"repos/{LAB_REPO}/actions/runs?per_page=100", CASE_DIR / "post_lab_runs.json"
    )
    rc, rulesets, err = gh_save(
        f"repos/{LAB_REPO}/rulesets?includes_parents=true&per_page=100",
        CASE_DIR / "post_lab_rulesets.json",
    )

    fail = []
    if prod.get("sha") != EXPECTED_PROD_MAIN:
        fail.append("PRODUCTION_MAIN_CHANGED")
    if (
        pr6.get("state") != "open"
        or pr6.get("merged") is not False
        or (pr6.get("head") or {}).get("sha") != EXPECTED_PR6_HEAD
        or (pr6.get("base") or {}).get("sha") != EXPECTED_PROD_MAIN
    ):
        fail.append("PR6_CHANGED")
    if lab_main.get("sha") != EXPECTED_LAB_MAIN:
        fail.append("LAB_MAIN_CHANGED")
    if rulesets != []:
        fail.append("RULESET_CREATED_DURING_ID_OBSERVATION")

    if not isinstance(prs, list) or len(prs) != 2:
        fail.append(f"UNEXPECTED_PR_COUNT:{len(prs) if isinstance(prs, list) else 'non-list'}")
    else:
        by_number = {p.get("number"): p for p in prs}
        pr1 = by_number.get(1) or {}
        pr2 = by_number.get(2) or {}
        if (
            pr1.get("state") != "closed"
            or pr1.get("merged_at") is not None
            or (pr1.get("base") or {}).get("sha") != HISTORICAL_ATTEMPT_1["target_sha"]
            or (pr1.get("head") or {}).get("sha") != HISTORICAL_ATTEMPT_1["source_sha"]
        ):
            fail.append("HISTORICAL_PR1_CHANGED")
        if (
            pr2.get("state") != "closed"
            or pr2.get("merged_at") is not None
            or (pr2.get("base") or {}).get("sha") != ATTEMPT["target_sha"]
            or (pr2.get("head") or {}).get("sha") != ATTEMPT["source_sha"]
        ):
            fail.append("ATTEMPT2_PR_NOT_CLOSED_UNMERGED")

    allowed = {
        (HISTORICAL_ATTEMPT_1["manifest_path"], HISTORICAL_ATTEMPT_1["source"]),
        (ATTEMPT["manifest_path"], ATTEMPT["source"]),
    }
    for wr in runs.get("workflow_runs") or []:
        if wr.get("event") != "pull_request":
            fail.append(f"UNEXPECTED_WORKFLOW_EVENT:{wr.get('id')}")
            continue
        if (wr.get("path"), wr.get("head_branch")) not in allowed:
            fail.append(f"UNEXPECTED_WORKFLOW_RUN:{wr.get('id')}")

    refs = git_ls_remote("refs/heads/*")
    heads = {k.removeprefix("refs/heads/"): v for k, v in refs.items()}
    if len(heads) != 61:
        fail.append(f"HEAD_COUNT_CHANGED:{len(heads)}")
    if heads.get("main") != EXPECTED_LAB_MAIN:
        fail.append("MAIN_REF_CHANGED")
    if heads.get(ATTEMPT["target"]) != ATTEMPT["target_sha"]:
        fail.append("ATTEMPT2_TARGET_REF_CHANGED")
    if heads.get(ATTEMPT["source"]) != ATTEMPT["source_sha"]:
        fail.append("ATTEMPT2_SOURCE_REF_CHANGED")

    try:
        verify_app_live(EXPECTED_APP, CASE_DIR, "post_expected")
        verify_app_live(WRONG_APP, CASE_DIR, "post_wrong")
    except StopBeforeMutation as exc:
        fail.append("APP_POSTFLIGHT_DRIFT:" + str(exc))

    safe_terminal = case_outcome in {
        "OBSERVATION_UNCERTAIN",
        ACQUISITION_EXHAUSTED_OUTCOME,
    }
    result = {
        "schema_version": 1,
        "artifact_type": "r2-4-stage-b-v14-v2-lab-id-observation-attempt2-result",
        "created_at_utc": utc_now(),
        "status": (
            "PASS"
            if not fail and case_outcome == "OBSERVATION_COMPLETE"
            else "SAFE_TERMINAL"
            if not fail and safe_terminal
            else "STOP_AFTER_MUTATION"
        ),
        "risk_class": "D",
        "case_id": "LAB-ID-OBSERVATION",
        "case_outcome": case_outcome,
        "attempts_executed_in_this_runner": 1,
        "historical_attempt_1": HISTORICAL_ATTEMPT_1_DISPOSITION,
        "attempt_results": attempt_results,
        "LAB_EXPECTED_APP_ID": EXPECTED_APP["id"],
        "LAB_EXPECTED_INSTALLATION_ID": EXPECTED_APP["installation_id"],
        "LAB_WRONG_APP_ID": WRONG_APP["id"],
        "LAB_WRONG_INSTALLATION_ID": WRONG_APP["installation_id"],
        "production_FALSE_GREENS": 8,
        "LAB_FALSE_GREENS": 0,
        "production_main_unchanged": prod.get("sha") == EXPECTED_PROD_MAIN,
        "PR6_unchanged": (
            pr6.get("state") == "open"
            and pr6.get("merged") is False
            and (pr6.get("head") or {}).get("sha") == EXPECTED_PR6_HEAD
            and (pr6.get("base") or {}).get("sha") == EXPECTED_PROD_MAIN
        ),
        "lab_main_unchanged": lab_main.get("sha") == EXPECTED_LAB_MAIN,
        "ruleset_count": len(rulesets) if isinstance(rulesets, list) else None,
        "open_lab_PR_count": len([p for p in prs if p.get("state") == "open"]) if isinstance(prs, list) else None,
        "all_case_PRs_closed_unmerged": (
            isinstance(prs, list)
            and len(prs) == 2
            and all(p.get("state") == "closed" and p.get("merged_at") is None for p in prs)
        ),
        "L2_started": False,
        "rulesets_created": False,
        "merge_performed": False,
        "cleanup_performed": False,
        "stop_all": safe_terminal,
        "failures": sorted(set(fail)),
        "next_if_OBSERVATION_COMPLETE": "No L2 execution without a fresh separate gate.",
        "next_if_safe_terminal": "Freeze evidence; STOP_ALL; L2 remains false.",
    }
    write_json(CASE_DIR / "L1_LAB_ID_OBSERVATION_V14_ATTEMPT2_RESULT.json", result)
    return result


def make_manifest() -> None:
    rows = []
    for path in sorted(p for p in CASE_DIR.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt"):
        rel = path.relative_to(CASE_DIR)
        rows.append(f"{sha256_file(path)}  {rel}")
    (CASE_DIR / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n", encoding="utf-8")


def validate_runner_review_execution_gate(
    *,
    self_sha: str,
    self_bytes: int,
    review_path: Path,
    authorized_review_sha: str,
) -> None:
    if not HEX64.fullmatch(authorized_review_sha):
        raise StopBeforeMutation("runner-review authorized SHA is not 64 lowercase hex")
    require_file(review_path, authorized_review_sha)
    review = json.loads(review_path.read_text(encoding="utf-8"))
    if review.get("artifact_type") != (
        "r2-4-stage-b-v14-v2-runner-candidate-independent-review-result"
    ):
        raise StopBeforeMutation("runner candidate review artifact type drift")
    if review.get("review_disposition") != "TECHNICAL_PASS_RUNNER_CANDIDATE_ONLY":
        raise StopBeforeMutation("runner candidate review is not technical PASS")
    if review.get("blocking_findings") != []:
        raise StopBeforeMutation("runner candidate review blockers nonempty")
    if review.get("required_changes_before_execution_Human_Gate_D") != []:
        raise StopBeforeMutation("runner candidate review required changes nonempty")
    if review.get("execution_authority") != "NONE":
        raise StopBeforeMutation("runner candidate review grants authority")
    if review.get("candidate_execution_authorized") is not False:
        raise StopBeforeMutation("runner candidate review execution-authorized flag drift")
    reviewer = review.get("reviewer") or {}
    if reviewer.get("independence_declaration_satisfied") is not True:
        raise StopBeforeMutation("runner candidate reviewer independence not satisfied")
    target = review.get("review_target") or {}
    if target.get("file") != Path(__file__).name:
        raise StopBeforeMutation("runner review target filename drift")
    if target.get("sha256") != self_sha:
        raise StopBeforeMutation("runner review target SHA drift")
    if target.get("bytes") != self_bytes:
        raise StopBeforeMutation("runner review target bytes drift")
    if target.get("integrity") != "PASS":
        raise StopBeforeMutation("runner review target integrity not PASS")


def main() -> int:
    self_path = Path(__file__).resolve()
    self_sha = sha256_file(self_path)
    self_bytes = self_path.stat().st_size
    if (
        len(sys.argv) != 7
        or sys.argv[1] != "--execute-authorized-sha"
        or sys.argv[2] != self_sha
        or sys.argv[3] != "--runner-review-result"
        or sys.argv[5] != "--runner-review-authorized-sha"
    ):
        print(
            "NOT_AUTHORIZED_TO_EXECUTE: exact candidate SHA and exact independent "
            "runner-review path/SHA are required",
            file=sys.stderr,
        )
        return 2
    if os.environ.get(EXECUTION_ENV) != EXECUTION_ENV_VALUE:
        print(f"NOT_AUTHORIZED_TO_EXECUTE: {EXECUTION_ENV}={EXECUTION_ENV_VALUE} required", file=sys.stderr)
        return 2
    review_path = Path(sys.argv[4]).expanduser().resolve()
    if review_path != RUNNER_REVIEW_RESULT.resolve():
        print("NOT_AUTHORIZED_TO_EXECUTE: runner-review path is not the fixed reviewed path", file=sys.stderr)
        return 2
    try:
        validate_runner_review_execution_gate(
            self_sha=self_sha,
            self_bytes=self_bytes,
            review_path=review_path,
            authorized_review_sha=sys.argv[6],
        )
    except StopBeforeMutation as exc:
        print(f"NOT_AUTHORIZED_TO_EXECUTE: {exc}", file=sys.stderr)
        return 2

    for cmd in ["gh", "git", "openssl"]:
        if not shutil_which(cmd):
            print(f"STOP: falta comando {cmd}", file=sys.stderr)
            return 3
    if not RUN_ROOT.is_dir():
        print(f"STOP: falta RUN_ROOT {RUN_ROOT}", file=sys.stderr)
        return 3
    if CASE_DIR.exists():
        print(f"STOP: {CASE_DIR} ya existe; no sobrescribir evidencia", file=sys.stderr)
        return 3
    CASE_DIR.mkdir(mode=0o700)

    mutation_started = False
    attempt_results: list[dict] = []
    try:
        static = validate_static_inputs()
        preflight(static)
        mutation_started = True
        result = execute_attempt(ATTEMPT)
        attempt_results.append(result)
        outcome = result["outcome"]

        if outcome == "OBSERVATION_COMPLETE":
            final = postflight(attempt_results, outcome)
            make_manifest()
            result_path = CASE_DIR / "L1_LAB_ID_OBSERVATION_V14_ATTEMPT2_RESULT.json"
            print(f"RESULT_SHA256={sha256_file(result_path)}")
            print(f"RESULT_BYTES={result_path.stat().st_size}")
            print(f"RESULT_STATUS={final['status']}")
            print("CASE_ID=LAB-ID-OBSERVATION")
            print("CASE_OUTCOME=OBSERVATION_COMPLETE")
            print("SUCCESSFUL_ATTEMPT=2")
            print(f"NATIVE_BINDING={result['native_binding']}")
            print(f"NATIVE_CHECK_RUN_ID={result['native_check_run_id']}")
            print(f"NATIVE_APP_ID={result['native_app_id']}")
            print(f"LAB_EXPECTED_CHECK_RUN_ID={result['expected_app_check_run_id']}")
            print(f"LAB_WRONG_CHECK_RUN_ID={result['wrong_app_check_run_id']}")
            print(f"PR_HEAD={result['PR_HEAD']}")
            print(f"TEST_MERGE={result['TEST_MERGE']}")
            print(f"ALL_CASE_PRS_CLOSED_UNMERGED={final['all_case_PRs_closed_unmerged']}")
            print(f"PRODUCTION_MAIN_UNCHANGED={final['production_main_unchanged']}")
            print(f"PR6_UNCHANGED={final['PR6_unchanged']}")
            print(f"LAB_MAIN_UNCHANGED={final['lab_main_unchanged']}")
            print("LAB_FALSE_GREENS=0")
            print("PRODUCTION_FALSE_GREENS=8")
            print("L2_STARTED=false")
            print("L1_LAB_ID_OBSERVATION_V14_ATTEMPT2_PASS")
            print(f"EVIDENCE_ROOT={CASE_DIR}")
            return 0

        if outcome in {"OBSERVATION_UNCERTAIN", ACQUISITION_EXHAUSTED_OUTCOME}:
            final = postflight(attempt_results, outcome)
            make_manifest()
            result_path = CASE_DIR / "L1_LAB_ID_OBSERVATION_V14_ATTEMPT2_RESULT.json"
            print(f"RESULT_SHA256={sha256_file(result_path)}")
            print(f"RESULT_BYTES={result_path.stat().st_size}")
            print(f"RESULT_STATUS={final['status']}")
            print(f"CASE_OUTCOME={outcome}")
            print("PR_TERMINAL_STATE=CLOSED_UNMERGED")
            print("EVIDENCE=FROZEN")
            print("STOP_ALL=true")
            print("L2_STARTED=false")
            print(f"EVIDENCE_ROOT={CASE_DIR}")
            return 5

        raise RuntimeError(f"unrecognized attempt-2 outcome: {outcome!r}")

    except StopBeforeMutation as exc:
        incident = {
            "status": "STOP_BEFORE_MUTATION",
            "reason": str(exc),
            "mutation_started": mutation_started,
            "created_at_utc": utc_now(),
        }
        write_json(CASE_DIR / "STOP.json", incident)
        make_manifest()
        print(f"L1_V14_ATTEMPT2_STOP_BEFORE_MUTATION: {exc}", file=sys.stderr)
        print("L2_STARTED=false", file=sys.stderr)
        return 3
    except ObservationInvalid as exc:
        incident = {
            "status": "OBSERVATION_INVALID_STOP",
            "case_outcome": "OBSERVATION_INVALID",
            "reason": str(exc),
            "mutation_started": mutation_started,
            "attempt_results": attempt_results,
            "created_at_utc": utc_now(),
            "instruction": "Freeze evidence. No third attempt. No cleanup.",
        }
        write_json(CASE_DIR / "OBSERVATION_INVALID_STOP.json", incident)
        make_manifest()
        print(f"L1_V14_ATTEMPT2_OBSERVATION_INVALID_STOP: {exc}", file=sys.stderr)
        print("L2_STARTED=false", file=sys.stderr)
        return 4
    except StopAfterMutation as exc:
        incident = {
            "status": "STOP_AFTER_MUTATION",
            "reason": str(exc),
            "mutation_started": mutation_started,
            "attempt_results": attempt_results,
            "created_at_utc": utc_now(),
            "instruction": "Freeze remote state and evidence. No cleanup or improvisation.",
        }
        write_json(CASE_DIR / "STOP_AFTER_MUTATION.json", incident)
        make_manifest()
        print(f"L1_V14_ATTEMPT2_STOP_AFTER_MUTATION: {exc}", file=sys.stderr)
        print("L2_STARTED=false", file=sys.stderr)
        return 4
    except Exception as exc:
        incident = {
            "status": "UNCLASSIFIED_RUNTIME_STOP",
            "reason_type": type(exc).__name__,
            "reason": str(exc),
            "mutation_started": mutation_started,
            "attempt_results": attempt_results,
            "created_at_utc": utc_now(),
            "instruction": "Freeze everything. Do not invent recovery or cleanup.",
        }
        write_json(CASE_DIR / "UNCLASSIFIED_RUNTIME_STOP.json", incident)
        make_manifest()
        print(f"L1_V14_ATTEMPT2_UNCLASSIFIED_RUNTIME_STOP: {type(exc).__name__}: {exc}", file=sys.stderr)
        print("L2_STARTED=false", file=sys.stderr)
        return 6


def shutil_which(cmd: str) -> str | None:
    import shutil
    return shutil.which(cmd)


if __name__ == "__main__":
    raise SystemExit(main())
